-- CREAR BASE DE DATOS
CREATE DATABASE SUSTI
--
-- CREAR TABLA PERSONAL
CREATE TABLE PERSONAL(
IdPersonal int primary key identity,
TipoDocumento varchar(10),
NroDocumento varchar(20),
Apaterno varchar(20),
Amaterno varchar(20),
Nombre varchar(20),
Sexo varchar(10),
EstadoCivil varchar(15)
)
-- 
-- PROCEDIMIENTO ALMACENADO: AGREGAR PERSONAL
CREATE PROCEDURE sp_agregar_personal  
    @TipoDocumento varchar(10),@NroDocumento varchar(20),@Apaterno varchar(20),
	@Amaterno varchar(20),@Nombre varchar(20),@Sexo varchar(10),@EstadoCivil varchar(15)
AS   
BEGIN    
	INSERT INTO PERSONAL (TipoDocumento,NroDocumento,Apaterno,Amaterno,Nombre,Sexo,EstadoCivil)
	VALUES (@TipoDocumento,@NroDocumento,@Apaterno,@Amaterno,@Nombre,@Sexo,@EstadoCivil)    
END
GO
--
-- PROCEDIMIENTO ALMACENADO: BUSCAR PERSONAL X ID
CREATE PROCEDURE sp_buscar_personal_por_id
	@IdPersonal INT     
AS   
BEGIN    
    SELECT IdPersonal,TipoDocumento,NroDocumento,Apaterno,Amaterno,Nombre,Sexo,EstadoCivil 
	FROM PERSONAL WHERE IdPersonal=@IdPersonal
END
GO
--
-- PROCEDIMIENTO ALMACENADO: LISTAR PERSONAL
CREATE PROCEDURE sp_listar_personal  	
AS   
BEGIN    
    SELECT IdPersonal,TipoDocumento,NroDocumento,Apaterno,Amaterno,Nombre,Sexo,EstadoCivil FROM PERSONAL
END
GO
