﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class ConexionBD
    {
        public static string ConnectionString = ConfigurationManager.ConnectionStrings["cnSusti"].ConnectionString;
    }
}
