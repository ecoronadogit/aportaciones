﻿using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class PersonalDL
    {
        public int AgregarPersonal(PersonalBE personal)
        {
            int resultado;
            using (var Con = new SqlConnection(ConexionBD.ConnectionString))
            {
                Con.Open();
                string query = "sp_agregar_personal";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pTipoDocumento = new SqlParameter();
                pTipoDocumento.ParameterName = "@TipoDocumento";
                pTipoDocumento.Value = personal.TipoDocumento;
                command.Parameters.Add(pTipoDocumento);

                SqlParameter pNroDocumento = new SqlParameter();
                pNroDocumento.ParameterName = "@NroDocumento";
                pNroDocumento.Value = personal.NroDocumento;
                command.Parameters.Add(pNroDocumento);

                SqlParameter pApaterno = new SqlParameter();
                pApaterno.ParameterName = "@Apaterno";
                pApaterno.Value = personal.Apaterno;
                command.Parameters.Add(pApaterno);

                SqlParameter pAmaterno = new SqlParameter();
                pAmaterno.ParameterName = "@Amaterno";
                pAmaterno.Value = personal.Amaterno;
                command.Parameters.Add(pAmaterno);

                SqlParameter pNombre = new SqlParameter();
                pNombre.ParameterName = "@Nombre";
                pNombre.Value = personal.Nombre;
                command.Parameters.Add(pNombre);

                SqlParameter pSexo = new SqlParameter();
                pSexo.ParameterName = "@Sexo";
                pSexo.Value = personal.Sexo;
                command.Parameters.Add(pSexo);

                SqlParameter pEstadoCivil = new SqlParameter();
                pEstadoCivil.ParameterName = "@EstadoCivil";
                pEstadoCivil.Value = personal.EstadoCivil;
                command.Parameters.Add(pEstadoCivil);

                resultado = command.ExecuteNonQuery();
            }
            return resultado;
        }

        public List<PersonalBE> BuscarPersonalPorId(int idPersonal)
        {
            List<PersonalBE> listaPersonal = new List<PersonalBE>();
            using (var Con = new SqlConnection(ConexionBD.ConnectionString))
            {
                Con.Open();
                string query = "sp_buscar_personal_por_id";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pIdPersonal = new SqlParameter();
                pIdPersonal.ParameterName = "@IdPersonal";
                pIdPersonal.Value = idPersonal;
                command.Parameters.Add(pIdPersonal);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    PersonalBE personal = new PersonalBE();
                    personal.IdPersonal = int.Parse(reader[0].ToString());
                    personal.TipoDocumento = reader[1].ToString();
                    personal.NroDocumento = reader[2].ToString();
                    personal.Apaterno = reader[3].ToString();
                    personal.Amaterno = reader[4].ToString();
                    personal.Nombre = reader[5].ToString();
                    personal.Sexo = reader[6].ToString();
                    personal.EstadoCivil = reader[7].ToString();
                    listaPersonal.Add(personal);
                }                                                
            }
            return listaPersonal;
        }

        public List<PersonalBE> ListarPersonal()
        {
            List<PersonalBE> listaPersonal = new List<PersonalBE>();
            using (var Con = new SqlConnection(ConexionBD.ConnectionString))
            {
                Con.Open();
                string query = "sp_listar_personal";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;                

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    PersonalBE personal = new PersonalBE();
                    personal.IdPersonal = int.Parse(reader[0].ToString());
                    personal.TipoDocumento = reader[1].ToString();
                    personal.NroDocumento = reader[2].ToString();
                    personal.Apaterno = reader[3].ToString();
                    personal.Amaterno = reader[4].ToString();
                    personal.Nombre = reader[5].ToString();
                    personal.Sexo = reader[6].ToString();
                    personal.EstadoCivil = reader[7].ToString();
                    listaPersonal.Add(personal);
                }
            }
            return listaPersonal;
        }
    }
}
