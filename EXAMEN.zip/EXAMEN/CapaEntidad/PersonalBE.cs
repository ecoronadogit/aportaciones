﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class PersonalBE
    {        
        public int IdPersonal { get; set; }
        public string TipoDocumento { get; set; }
        public string NroDocumento { get; set; }
        public string Apaterno { get; set; }
        public string Amaterno { get; set; }
        public string Nombre { get; set; }
        public string Sexo { get; set; }
        public string EstadoCivil { get; set; } 
    }
}
