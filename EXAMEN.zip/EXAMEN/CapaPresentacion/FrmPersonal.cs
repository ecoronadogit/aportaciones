﻿using CapaEntidad;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmPersonal : Form
    {
        public FrmPersonal()
        {
            InitializeComponent();
            ListarTipoDocumento();
            ListarSexo();
            ListarEstadoCivil();
        }

        PersonalBL personalBL = new PersonalBL();

        private void ListarTipoDocumento()
        {
            cboTipoDoc.Items.Add("CE");
            cboTipoDoc.Items.Add("DNI");            
        }

        private void ListarSexo()
        {
            cboSexo.Items.Add("Masculino");
            cboSexo.Items.Add("Femenino");
        }

        private void ListarEstadoCivil()
        {
            cboEstadoCivil.Items.Add("Soltero/a");
            cboEstadoCivil.Items.Add("Casado/a");
            cboEstadoCivil.Items.Add("Viudo/a");
            cboEstadoCivil.Items.Add("Divorciado/a");
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtApePaterno.Text = "";
            txtApeMaterno.Text = "";
            txtNombre.Text = "";
            cboTipoDoc.Text = "";
            txtNumeroDoc.Text = "";
            cboSexo.Text = "";
            cboEstadoCivil.Text = "";
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (txtId.Text.Trim() == "")
            {
                dgvPersonal.DataSource = personalBL.ListarPersonal();
            }
            else
            {
                int id = int.Parse(txtId.Text.Trim());
                dgvPersonal.DataSource = personalBL.BuscarPersonalPorId(id);
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            PersonalBE personal = new PersonalBE();
            personal.Apaterno = txtApePaterno.Text;
            personal.Amaterno = txtApeMaterno.Text;
            personal.Nombre = txtNombre.Text;
            personal.TipoDocumento = cboTipoDoc.Text;
            personal.NroDocumento = txtNumeroDoc.Text;
            personal.Sexo = cboSexo.Text;
            personal.EstadoCivil = cboEstadoCivil.Text;

            personalBL.AgregarPersonal(personal);
            MessageBox.Show("personal Agregado");
        }
    }
}
