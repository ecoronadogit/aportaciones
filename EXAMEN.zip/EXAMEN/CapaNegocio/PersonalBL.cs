﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class PersonalBL
    {
        PersonalDL personalDL = new PersonalDL();

        public int AgregarPersonal(PersonalBE personal)
        {
            int resultado = personalDL.AgregarPersonal(personal);
            return resultado;
        }

        public List<PersonalBE> BuscarPersonalPorId(int id)
        {
            List<PersonalBE> personal = personalDL.BuscarPersonalPorId(id);
            return personal;
        }

        public List<PersonalBE> ListarPersonal()
        {
            List<PersonalBE> lista = personalDL.ListarPersonal();
            return lista;
        }
    }
}
