﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class LoginCN
    {        
        public int Validar(Login login)
        {
            int retorno = -1;
            int resultado;            
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_verificar_login";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pUsuario = new SqlParameter();
                pUsuario.ParameterName = "@Usuario";
                pUsuario.Value = login.Usuario;                
                command.Parameters.Add(pUsuario);

                SqlParameter pContrasena = new SqlParameter();
                pContrasena.ParameterName = "@Contrasena";
                pContrasena.Value = login.Contrasena;
                command.Parameters.Add(pContrasena);

                SqlParameter pValido = new SqlParameter();
                pValido.ParameterName = "@Valido";
                pValido.DbType = DbType.Int16;
                pValido.Direction = ParameterDirection.Output;                
                command.Parameters.Add(pValido);

                retorno = command.ExecuteNonQuery();
                //command.ExecuteReader();
                resultado = int.Parse(pValido.Value.ToString());
            }
            return resultado;
        }       
    }
}
