﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class SocioCN
    {
        public int Validar(Socio socio)
        {
            int retorno = -1;
            int resultado;
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_verificar_socio";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pNumeroDocumento = new SqlParameter();
                pNumeroDocumento.ParameterName = "@NumeroDocumento";
                pNumeroDocumento.Value = socio.NumeroDocumento;
                command.Parameters.Add(pNumeroDocumento);               

                SqlParameter pCodigoSocio = new SqlParameter();
                pCodigoSocio.ParameterName = "@CodigoSocio";
                pCodigoSocio.DbType = DbType.Int16;
                pCodigoSocio.Direction = ParameterDirection.Output;
                command.Parameters.Add(pCodigoSocio);

                retorno = command.ExecuteNonQuery();
                //command.ExecuteReader();
                if (pCodigoSocio.Value.ToString()=="")
                {
                    resultado = 0;
                }
                else
                {
                    resultado = int.Parse(pCodigoSocio.Value.ToString());
                }                
            }
            return resultado;
        }

        public int Registrar(Socio socio)
        {
            int retorno = -1;
            int resultado;
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_registrar_socio";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pTipoDocumento = new SqlParameter();
                pTipoDocumento.ParameterName = "@TipoDocumento";
                pTipoDocumento.Value = socio.TipoDocumento;
                command.Parameters.Add(pTipoDocumento);

                SqlParameter pNumeroDocumento = new SqlParameter();
                pNumeroDocumento.ParameterName = "@NumeroDocumento";
                pNumeroDocumento.Value = socio.NumeroDocumento;
                command.Parameters.Add(pNumeroDocumento);

                SqlParameter pNombre = new SqlParameter();
                pNombre.ParameterName = "@Nombre";
                pNombre.Value = socio.Nombre;
                command.Parameters.Add(pNombre);

                SqlParameter pDireccion = new SqlParameter();
                pDireccion.ParameterName = "@Direccion";
                pDireccion.Value = socio.Direccion;
                command.Parameters.Add(pDireccion);

                SqlParameter pDepartamento = new SqlParameter();
                pDepartamento.ParameterName = "@Departamento";
                pDepartamento.Value = socio.Departamento;
                command.Parameters.Add(pDepartamento);

                SqlParameter pProvincia = new SqlParameter();
                pProvincia.ParameterName = "@Provincia";
                pProvincia.Value = socio.Provincia;
                command.Parameters.Add(pProvincia);

                SqlParameter pDistrito = new SqlParameter();
                pDistrito.ParameterName = "@Distrito";
                pDistrito.Value = socio.Distrito;
                command.Parameters.Add(pDistrito);

                SqlParameter pTelefono = new SqlParameter();
                pTelefono.ParameterName = "@Telefono";
                pTelefono.Value = socio.Telefono;
                command.Parameters.Add(pTelefono);

                SqlParameter pCorreo = new SqlParameter();
                pCorreo.ParameterName = "@Correo";
                pCorreo.Value = socio.Correo;
                command.Parameters.Add(pCorreo);
                
                resultado = command.ExecuteNonQuery();  
            }
            return resultado;
        }

        public List<Socio> ListarTodos()
        {
            List<Socio> listaSocios = new List<Socio>();
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_buscar_socios_todos";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;               

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Socio socio = new Socio();
                    socio.CodigoSocio = int.Parse(reader[0].ToString());
                    socio.TipoDocumento = reader[1].ToString();
                    socio.NumeroDocumento = reader[2].ToString();
                    socio.Nombre = reader[3].ToString();
                    socio.Direccion = reader[4].ToString();
                    socio.Departamento = reader[5].ToString();
                    socio.Provincia = reader[6].ToString();
                    socio.Distrito = reader[7].ToString();
                    socio.Telefono = reader[8].ToString();
                    socio.Correo = reader[9].ToString();
                    listaSocios.Add(socio);
                }
            }
            return listaSocios;
        }

        public List<Socio> ListarPorDepartamento(string departamento)
        {
            List<Socio> listaSocios = new List<Socio>();
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_buscar_socios_departamento";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pDepartamento = new SqlParameter();
                pDepartamento.ParameterName = "@Departamento";
                pDepartamento.Value = departamento;
                command.Parameters.Add(pDepartamento);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Socio socio = new Socio();
                    socio.CodigoSocio = int.Parse(reader[0].ToString());
                    socio.TipoDocumento = reader[1].ToString();
                    socio.NumeroDocumento = reader[2].ToString();
                    socio.Nombre = reader[3].ToString();
                    socio.Direccion = reader[4].ToString();
                    socio.Departamento = reader[5].ToString();
                    socio.Provincia = reader[6].ToString();
                    socio.Distrito = reader[7].ToString();
                    socio.Telefono = reader[8].ToString();
                    socio.Correo = reader[9].ToString();
                    listaSocios.Add(socio);
                }
            }
            return listaSocios;
        }

        public List<Socio> ListarPorProvincia(string provincia)
        {
            List<Socio> listaSocios = new List<Socio>();
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_buscar_socios_provincia";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pProvincia = new SqlParameter();
                pProvincia.ParameterName = "@Provincia";
                pProvincia.Value = provincia;
                command.Parameters.Add(pProvincia);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Socio socio = new Socio();
                    socio.CodigoSocio = int.Parse(reader[0].ToString());
                    socio.TipoDocumento = reader[1].ToString();
                    socio.NumeroDocumento = reader[2].ToString();
                    socio.Nombre = reader[3].ToString();
                    socio.Direccion = reader[4].ToString();
                    socio.Departamento = reader[5].ToString();
                    socio.Provincia = reader[6].ToString();
                    socio.Distrito = reader[7].ToString();
                    socio.Telefono = reader[8].ToString();
                    socio.Correo = reader[9].ToString();
                    listaSocios.Add(socio);
                }
            }
            return listaSocios;
        }

        public List<Socio> ListarPorDistrito(string distrito)
        {
            List<Socio> listaSocios = new List<Socio>();
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_buscar_socios_distrito";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pDistrito = new SqlParameter();
                pDistrito.ParameterName = "@Distrito";
                pDistrito.Value = distrito;
                command.Parameters.Add(pDistrito);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Socio socio = new Socio();
                    socio.CodigoSocio = int.Parse(reader[0].ToString());
                    socio.TipoDocumento = reader[1].ToString();
                    socio.NumeroDocumento = reader[2].ToString();
                    socio.Nombre = reader[3].ToString();
                    socio.Direccion = reader[4].ToString();
                    socio.Departamento = reader[5].ToString();
                    socio.Provincia = reader[6].ToString();
                    socio.Distrito = reader[7].ToString();
                    socio.Telefono = reader[8].ToString();
                    socio.Correo = reader[9].ToString();
                    listaSocios.Add(socio);
                }
            }
            return listaSocios;
        }

        public bool ExisteSocio(int codigo)
        {            
            bool resultado=false;
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_existe_socio";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pCodigo = new SqlParameter();
                pCodigo.ParameterName = "@CodigoSocio";
                pCodigo.Value = codigo;
                command.Parameters.Add(pCodigo);                

                SqlParameter pValido = new SqlParameter();
                pValido.ParameterName = "@Valido";
                pValido.DbType = DbType.Int16;
                pValido.Direction = ParameterDirection.Output;
                command.Parameters.Add(pValido);

                command.ExecuteNonQuery();
                if (int.Parse(pValido.Value.ToString()) > 0)
                {
                    resultado = true;
                }                
            }
            return resultado;
        }

        public string NombreSocio(int codigo)
        {
            string nombreSocio = "";
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_nombre_socio";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pCodigo = new SqlParameter();
                pCodigo.ParameterName = "@CodigoSocio";
                pCodigo.Value = codigo;
                command.Parameters.Add(pCodigo);

                try
                {
                    nombreSocio = command.ExecuteScalar().ToString();
                }
                catch (Exception)
                {
                    nombreSocio = "";
                }
            }
            return nombreSocio;
        }
    }
}
