﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class CuentaCN
    {
        public int RegistrarAbono(CuentaCorriente cuenta)
        {            
            int resultado;
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_registrar_abono";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pCodigoSocio = new SqlParameter();
                pCodigoSocio.ParameterName = "@CodigoSocio";
                pCodigoSocio.Value = cuenta.CodigoSocio;
                command.Parameters.Add(pCodigoSocio);

                SqlParameter pFecha = new SqlParameter();
                pFecha.ParameterName = "@Fecha";
                pFecha.Value = cuenta.Fecha;
                command.Parameters.Add(pFecha);

                SqlParameter pConcepto = new SqlParameter();
                pConcepto.ParameterName = "@Concepto";
                pConcepto.Value = cuenta.Concepto;
                command.Parameters.Add(pConcepto);                

                SqlParameter pAbono = new SqlParameter();
                pAbono.ParameterName = "@Abono";
                pAbono.Value = cuenta.Abono;
                command.Parameters.Add(pAbono);

                SqlParameter pTipoAbono = new SqlParameter();
                pTipoAbono.ParameterName = "@TipoAbono";
                pTipoAbono.Value = cuenta.TipoAbono;
                command.Parameters.Add(pTipoAbono);

                SqlParameter pEntidadFinanciera = new SqlParameter();
                pEntidadFinanciera.ParameterName = "@EntidadFinanciera";
                pEntidadFinanciera.Value = cuenta.EntidadFinanciera;
                command.Parameters.Add(pEntidadFinanciera);                

                SqlParameter pNumeroOperacion = new SqlParameter();
                pNumeroOperacion.ParameterName = "@NumeroOperacion";
                pNumeroOperacion.Value = cuenta.NumeroOperacion;
                command.Parameters.Add(pNumeroOperacion);                              

                resultado = command.ExecuteNonQuery();
            }
            return resultado;
        }

        public int RegistrarCargo(CuentaCorriente cuenta)
        {
            int resultado;
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_registrar_cargo";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pCodigoSocio = new SqlParameter();
                pCodigoSocio.ParameterName = "@CodigoSocio";
                pCodigoSocio.Value = cuenta.CodigoSocio;
                command.Parameters.Add(pCodigoSocio);

                SqlParameter pFecha = new SqlParameter();
                pFecha.ParameterName = "@Fecha";
                pFecha.Value = cuenta.Fecha;
                command.Parameters.Add(pFecha);

                SqlParameter pConcepto = new SqlParameter();
                pConcepto.ParameterName = "@Concepto";
                pConcepto.Value = cuenta.Concepto;
                command.Parameters.Add(pConcepto);

                SqlParameter pCargo = new SqlParameter();
                pCargo.ParameterName = "@Cargo";
                pCargo.Value = cuenta.Cargo;
                command.Parameters.Add(pCargo);                

                resultado = command.ExecuteNonQuery();
            }
            return resultado;
        }

        public List<DetalleCuenta> ListarDetalleCuenta(int codigo)
        {
            List<DetalleCuenta> listaDetalleCuenta = new List<DetalleCuenta>();
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_detalle_cuenta";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pCodigo = new SqlParameter();
                pCodigo.ParameterName = "@CodigoSocio";
                pCodigo.Value = codigo;
                command.Parameters.Add(pCodigo);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    DetalleCuenta detalle = new DetalleCuenta();
                    detalle.Fecha = reader[0].ToString();
                    detalle.Concepto = reader[1].ToString();
                    detalle.Cargo = reader[2].ToString();
                    detalle.Abono = reader[3].ToString();
                    detalle.Saldo = reader[4].ToString();
                    listaDetalleCuenta.Add(detalle);
                }
            }
            return listaDetalleCuenta;
        }

        public string SaldoCuenta(int codigo)
        {
            string saldoCuenta = "";
            using (var Con = new SqlConnection(Conexion.ConnectionString))
            {
                Con.Open();
                string query = "sp_saldo_cuenta";
                SqlCommand command = new SqlCommand();
                command.Connection = Con;
                command.CommandText = query;
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter pCodigo = new SqlParameter();
                pCodigo.ParameterName = "@CodigoSocio";
                pCodigo.Value = codigo;
                command.Parameters.Add(pCodigo);

                try
                {
                    saldoCuenta= command.ExecuteScalar().ToString();
                }
                catch (Exception)
                {
                    saldoCuenta = "0";
                }                
            }
            return saldoCuenta;
        }
    }
}
