﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class DetalleCuenta
    {      
        public string Fecha { get; set; }
        public string Concepto { get; set; }
        public string Cargo { get; set; }
        public string Abono { get; set; }
        public string Saldo { get; set; }        
    }
}
