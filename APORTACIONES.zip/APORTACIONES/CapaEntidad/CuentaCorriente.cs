﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class CuentaCorriente
    {
        public int CodigoSocio { get; set; }
        public string Fecha { get; set; }
        public string Concepto { get; set; }
        public decimal Cargo { get; set; }
        public decimal Abono { get; set; }
        public string TipoAbono { get; set; }
        public string EntidadFinanciera { get; set; }
        public string NumeroOperacion { get; set; }
    }
}
