﻿using CapaEntidad;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmAbono : Form
    {
        public frmAbono()
        {
            InitializeComponent();
            ListarTipoAbono();
        }

        SocioCN socioCN = new SocioCN();
        CuentaCN cuentaCN = new CuentaCN();

        private void ListarTipoAbono()
        {
            cboTipoAbono.Items.Add("Efectivo");
            cboTipoAbono.Items.Add("Transferencia");
            cboTipoAbono.Items.Add("Otros");            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnRegistrarAbono_Click(object sender, EventArgs e)
        {
            int fecha = dtpFechaAbono.Value.Year * 10000 + dtpFechaAbono.Value.Month * 100 + dtpFechaAbono.Value.Day;
            if (txtCodigoSocio.Text.Trim() == "" || txtImporte.Text.Trim() == "")
            {
                if (txtCodigoSocio.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese Codigo de Socio");
                }
                else
                {
                    MessageBox.Show("Ingrese Importe");
                }                
            }
            else
            {
                if (ValidarImporte() && ValidarSocio())
                {
                    CuentaCorriente obj = new CuentaCorriente();
                    obj.CodigoSocio = int.Parse(txtCodigoSocio.Text);
                    obj.Fecha = fecha.ToString();
                    obj.Concepto = "Aporte";
                    obj.Abono = decimal.Parse(txtImporte.Text.Trim());
                    obj.TipoAbono = cboTipoAbono.Text;
                    obj.EntidadFinanciera = txtEntidadFinanciera.Text;
                    obj.NumeroOperacion = txtNumeroOperacion.Text;

                    cuentaCN.RegistrarAbono(obj);
                    MessageBox.Show("Abono Registrado");
                    //LimpiarDatos();
                }
                else
                {
                    if (!ValidarImporte())
                    {
                        MessageBox.Show("Ingrese Importe Corecto");
                    }
                    else
                    {
                        MessageBox.Show("Ingrese Codigo de Socio Correcto");
                    }
                }                
            }            
        }

        private bool ValidarImporte()
        {            
            bool res;
            decimal importe;            
            res = decimal.TryParse(txtImporte.Text.Trim(), out importe);
            return res;
        }

        private bool ValidarSocio()
        {
            //txtCodigoSocio.Text.Trim()
            bool socioValido=false;
            bool res;
            int codigo;
            res = int.TryParse(txtCodigoSocio.Text.Trim(), out codigo);
            if (res)
            {
                socioValido = socioCN.ExisteSocio(codigo);
            }            
            return socioValido;
        }
    }
}
