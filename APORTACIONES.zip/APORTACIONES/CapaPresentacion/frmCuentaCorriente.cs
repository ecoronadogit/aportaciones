﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmCuentaCorriente : Form
    {
        public frmCuentaCorriente()
        {
            InitializeComponent();
        }

        SocioCN socioCN = new SocioCN();
        CuentaCN cuentaCN = new CuentaCN();

        private void btnBuscarTodos_Click(object sender, EventArgs e)
        {
            if (txtCodigoSocio.Text.Trim() == "")
            {
                MessageBox.Show("Ingrese Codigo de Socio");
            }
            else
            {
                if (ValidarSocio())
                {
                    dgvDetalleCuenta.DataSource = cuentaCN.ListarDetalleCuenta(int.Parse(txtCodigoSocio.Text.Trim()));
                    txtSaldoSocio.Text = cuentaCN.SaldoCuenta(int.Parse(txtCodigoSocio.Text.Trim()));
                    txtNombreSocio.Text = socioCN.NombreSocio(int.Parse(txtCodigoSocio.Text.Trim()));
                }
                else
                {
                    MessageBox.Show("Ingrese Codigo de Socio Correcto");
                }
            }
        }

        private bool ValidarSocio()
        {            
            bool socioValido = false;
            bool res;
            int codigo;
            res = int.TryParse(txtCodigoSocio.Text.Trim(), out codigo);
            if (res)
            {
                socioValido = socioCN.ExisteSocio(codigo);
            }
            return socioValido;
        }
    }
}
