﻿using CapaEntidad;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmRegistrarSocio : Form
    {
        public frmRegistrarSocio()
        {
            InitializeComponent();
            ListarTipoDocumento();
        }

        SocioCN socioCN = new SocioCN();

        private void ListarTipoDocumento()
        {
            cboTipoDocumento.Items.Add("DNI");
            cboTipoDocumento.Items.Add("CE");            
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (txtNumeroDocumento.Text.Trim() == "")
            {
                MessageBox.Show("Ingrese el Numero de Documento");
            }
            else
            {
                Socio obj = new Socio();
                obj.TipoDocumento = cboTipoDocumento.Text;
                obj.NumeroDocumento = txtNumeroDocumento.Text.Trim();
                obj.Nombre = txtNombre.Text.Trim();
                obj.Direccion = txtDireccion.Text.Trim();
                obj.Departamento = txtDepartamento.Text.Trim();
                obj.Provincia = txtProvincia.Text.Trim();
                obj.Distrito = txtDistrito.Text.Trim();
                obj.Telefono = txtTelefono.Text.Trim();
                obj.Correo = txtCorreo.Text.Trim();

                int codSocio=-1;
                codSocio = socioCN.Validar(obj);

                if (codSocio>=1)
                {
                    MessageBox.Show("El Socio ya esta registrado, "+"CodigoSocio="+codSocio.ToString());
                }
                else
                {
                    socioCN.Registrar(obj);
                    MessageBox.Show("Socio Registrado");
                    LimpiarDatos();
                }
            }                       
        }

        private void LimpiarDatos()
        {
            foreach (Control c in this.Controls)
            {
                if (c is GroupBox)
                {
                    foreach (Control c1 in c.Controls)
                    {
                        if (c1 is TextBox)
                        {
                            c1.Text = "";
                        }
                        if (c1 is ComboBox)
                        {
                            ComboBox cbo = (ComboBox)c1;
                            cbo.SelectedIndex = -1;
                        }                        
                    }
                }
            }            
        }
    }
}
