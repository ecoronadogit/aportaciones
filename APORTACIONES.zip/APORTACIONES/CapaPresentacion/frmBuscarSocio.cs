﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmBuscarSocio : Form
    {
        public frmBuscarSocio()
        {
            InitializeComponent();
        }

        SocioCN socioCN = new SocioCN();

        private void btnBuscarTodos_Click(object sender, EventArgs e)
        {
            dgvSocios.DataSource = socioCN.ListarTodos();
        }

        private void frmBuscarSocio_Load(object sender, EventArgs e)
        {
            
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (rbDepartamento.Checked)
            {
                if (txtDepartamento.Text.Trim()=="")
                {
                    MessageBox.Show("Ingrese un departamento");
                }
                else
                {
                    dgvSocios.DataSource = socioCN.ListarPorDepartamento(txtDepartamento.Text.Trim());
                }
            }
            else if (rbProvincia.Checked)
            {
                if (txtProvincia.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese una provincia");
                }
                else
                {
                    dgvSocios.DataSource = socioCN.ListarPorProvincia(txtProvincia.Text.Trim());
                }
            }
            else if (rbDistrito.Checked)
            {
                if (txtDistrito.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese un distrito");
                }
                else
                {
                    dgvSocios.DataSource = socioCN.ListarPorDistrito(txtDistrito.Text.Trim());
                }
            }
            else
            {
                MessageBox.Show("Seleccione una condicion");
            }
        }
    }
}
