﻿using CapaEntidad;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmCargo : Form
    {
        public frmCargo()
        {
            InitializeComponent();
        }

        SocioCN socioCN = new SocioCN();
        CuentaCN cuentaCN = new CuentaCN();

        private void btnRegistrarCargo_Click(object sender, EventArgs e)
        {
            int fecha = dtpFechaCargo.Value.Year * 10000 + dtpFechaCargo.Value.Month * 100 + dtpFechaCargo.Value.Day;
            if (txtCodigoSocio.Text.Trim() == "" || txtImporte.Text.Trim() == "")
            {
                if (txtCodigoSocio.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese Codigo de Socio");
                }
                else
                {
                    MessageBox.Show("Ingrese Importe");
                }
            }
            else
            {
                if (ValidarImporte() && ValidarSocio())
                {
                    CuentaCorriente obj = new CuentaCorriente();
                    obj.CodigoSocio = int.Parse(txtCodigoSocio.Text);
                    obj.Fecha = fecha.ToString();
                    obj.Concepto = txtConcepto.Text;
                    obj.Cargo = decimal.Parse(txtImporte.Text.Trim());                    

                    cuentaCN.RegistrarCargo(obj);
                    MessageBox.Show("Cargo Registrado");
                    //LimpiarDatos();
                }
                else
                {
                    if (!ValidarImporte())
                    {
                        MessageBox.Show("Ingrese Importe Correcto");
                    }
                    else
                    {
                        MessageBox.Show("Ingrese Codigo de Socio Corecto");
                    }
                }
            }
        }

        private bool ValidarImporte()
        {
            bool res;
            decimal importe;
            res = decimal.TryParse(txtImporte.Text.Trim(), out importe);
            return res;
        }

        private bool ValidarSocio()
        {
            //txtCodigoSocio.Text.Trim()
            bool socioValido = false;
            bool res;
            int codigo;
            res = int.TryParse(txtCodigoSocio.Text.Trim(), out codigo);
            if (res)
            {
                socioValido = socioCN.ExisteSocio(codigo);
            }
            return socioValido;
        }
    }
}
