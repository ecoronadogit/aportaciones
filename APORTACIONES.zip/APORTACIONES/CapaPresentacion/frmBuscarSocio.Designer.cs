﻿namespace CapaPresentacion
{
    partial class frmBuscarSocio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDepartamento = new System.Windows.Forms.TextBox();
            this.rbDepartamento = new System.Windows.Forms.RadioButton();
            this.btnBuscarTodos = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.txtDistrito = new System.Windows.Forms.TextBox();
            this.txtProvincia = new System.Windows.Forms.TextBox();
            this.rbDistrito = new System.Windows.Forms.RadioButton();
            this.rbProvincia = new System.Windows.Forms.RadioButton();
            this.dgvSocios = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSocios)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDepartamento
            // 
            this.txtDepartamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(220)))));
            this.txtDepartamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDepartamento.Location = new System.Drawing.Point(224, 12);
            this.txtDepartamento.Name = "txtDepartamento";
            this.txtDepartamento.Size = new System.Drawing.Size(282, 20);
            this.txtDepartamento.TabIndex = 18;
            // 
            // rbDepartamento
            // 
            this.rbDepartamento.AutoSize = true;
            this.rbDepartamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbDepartamento.Location = new System.Drawing.Point(82, 12);
            this.rbDepartamento.Name = "rbDepartamento";
            this.rbDepartamento.Size = new System.Drawing.Size(136, 20);
            this.rbDepartamento.TabIndex = 19;
            this.rbDepartamento.TabStop = true;
            this.rbDepartamento.Text = "Departamento : ";
            this.rbDepartamento.UseVisualStyleBackColor = true;
            // 
            // btnBuscarTodos
            // 
            this.btnBuscarTodos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(210)))), ((int)(((byte)(250)))));
            this.btnBuscarTodos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscarTodos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarTodos.Location = new System.Drawing.Point(610, 65);
            this.btnBuscarTodos.Name = "btnBuscarTodos";
            this.btnBuscarTodos.Size = new System.Drawing.Size(100, 25);
            this.btnBuscarTodos.TabIndex = 33;
            this.btnBuscarTodos.Text = "Buscar Todos";
            this.btnBuscarTodos.UseVisualStyleBackColor = false;
            this.btnBuscarTodos.Click += new System.EventHandler(this.btnBuscarTodos_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(240)))), ((int)(((byte)(190)))));
            this.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscar.Location = new System.Drawing.Point(599, 12);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(120, 40);
            this.btnBuscar.TabIndex = 32;
            this.btnBuscar.Text = "BUSCAR";
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // txtDistrito
            // 
            this.txtDistrito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(220)))));
            this.txtDistrito.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDistrito.Location = new System.Drawing.Point(224, 72);
            this.txtDistrito.Name = "txtDistrito";
            this.txtDistrito.Size = new System.Drawing.Size(282, 20);
            this.txtDistrito.TabIndex = 22;
            // 
            // txtProvincia
            // 
            this.txtProvincia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(220)))));
            this.txtProvincia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProvincia.Location = new System.Drawing.Point(224, 41);
            this.txtProvincia.Name = "txtProvincia";
            this.txtProvincia.Size = new System.Drawing.Size(282, 20);
            this.txtProvincia.TabIndex = 20;
            // 
            // rbDistrito
            // 
            this.rbDistrito.AutoSize = true;
            this.rbDistrito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbDistrito.Location = new System.Drawing.Point(82, 70);
            this.rbDistrito.Name = "rbDistrito";
            this.rbDistrito.Size = new System.Drawing.Size(87, 20);
            this.rbDistrito.TabIndex = 23;
            this.rbDistrito.TabStop = true;
            this.rbDistrito.Text = "Distrito : ";
            this.rbDistrito.UseVisualStyleBackColor = true;
            // 
            // rbProvincia
            // 
            this.rbProvincia.AutoSize = true;
            this.rbProvincia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbProvincia.Location = new System.Drawing.Point(82, 41);
            this.rbProvincia.Name = "rbProvincia";
            this.rbProvincia.Size = new System.Drawing.Size(103, 20);
            this.rbProvincia.TabIndex = 21;
            this.rbProvincia.TabStop = true;
            this.rbProvincia.Text = "Provincia : ";
            this.rbProvincia.UseVisualStyleBackColor = true;
            // 
            // dgvSocios
            // 
            this.dgvSocios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSocios.Location = new System.Drawing.Point(31, 125);
            this.dgvSocios.Name = "dgvSocios";
            this.dgvSocios.Size = new System.Drawing.Size(748, 313);
            this.dgvSocios.TabIndex = 34;
            // 
            // frmBuscarSocio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvSocios);
            this.Controls.Add(this.txtDepartamento);
            this.Controls.Add(this.rbDepartamento);
            this.Controls.Add(this.btnBuscarTodos);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.txtDistrito);
            this.Controls.Add(this.txtProvincia);
            this.Controls.Add(this.rbDistrito);
            this.Controls.Add(this.rbProvincia);
            this.Name = "frmBuscarSocio";
            this.Text = "frmBuscarSocio";
            this.Load += new System.EventHandler(this.frmBuscarSocio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSocios)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDepartamento;
        private System.Windows.Forms.RadioButton rbDepartamento;
        private System.Windows.Forms.Button btnBuscarTodos;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.TextBox txtDistrito;
        private System.Windows.Forms.TextBox txtProvincia;
        private System.Windows.Forms.RadioButton rbDistrito;
        private System.Windows.Forms.RadioButton rbProvincia;
        private System.Windows.Forms.DataGridView dgvSocios;
    }
}