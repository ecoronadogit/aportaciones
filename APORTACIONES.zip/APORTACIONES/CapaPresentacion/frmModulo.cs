﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmModulo : Form
    {
        public frmModulo()
        {
            InitializeComponent();
        }

        private void frmModulo_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void socioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void registrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is frmRegistrarSocio)
                {
                    f.Focus();
                    return;
                }
            }
            frmRegistrarSocio frmReg = new frmRegistrarSocio();
            frmReg.MdiParent = this;
            frmReg.Show();
            frmReg.Focus();
        }

        private void buscarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is frmBuscarSocio)
                {
                    f.Focus();
                    return;
                }
            }
            frmBuscarSocio frmBus = new frmBuscarSocio();
            frmBus.MdiParent = this;
            frmBus.Show();
            frmBus.Focus();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cuentaCorrienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is frmCuentaCorriente)
                {
                    f.Focus();
                    return;
                }
            }
            frmCuentaCorriente frmCuenta = new frmCuentaCorriente();
            frmCuenta.MdiParent = this;
            frmCuenta.Show();
            frmCuenta.Focus();
        }

        private void abonoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is frmAbono)
                {
                    f.Focus();
                    return;
                }
            }
            frmAbono frmAbo = new frmAbono();
            frmAbo.MdiParent = this;
            frmAbo.Show();
            frmAbo.Focus();
        }

        private void cargoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is frmCargo)
                {
                    f.Focus();
                    return;
                }
            }
            frmCargo frmCar = new frmCargo();
            frmCar.MdiParent = this;
            frmCar.Show();
            frmCar.Focus();
        }
    }
}
