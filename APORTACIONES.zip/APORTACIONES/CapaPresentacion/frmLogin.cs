﻿using CapaEntidad;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        LoginCN loginCN = new LoginCN();

        private void btnEntrar_Click(object sender, EventArgs e)
        {            
            if (txtUsuario.Text.Trim() == "" || txtContrasena.Text.Trim() == "")
            {
                lblMensaje.Text = "Ingrese Usuario y/o Contraseña";
            }
            else
            {
                Login obj = new Login();
                int valido = 0;
                obj.Usuario = txtUsuario.Text.Trim();
                obj.Contrasena = txtContrasena.Text.Trim();

                valido = loginCN.Validar(obj);
                
                if (valido >= 1)
                {
                    this.Hide();
                    frmModulo modulo = new frmModulo();
                    modulo.Show();
                }
                else
                {
                    lblMensaje.Text = "Usuario y/o Contraseña INCORRECTO(s)";
                }
            }            
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
